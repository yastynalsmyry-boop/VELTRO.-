# VELTRO — Narration script (English, male documentary voice)

Timings match `src/config.ts` (CUES). Save the final voice-over as `public/audio/narration.mp3`
then set `FEATURES.narration = true` in `src/config.ts`.

| Time (s)    | Line |
|-------------|------|
| 0.5 – 6.0   | From the island of Madeira, Portugal, a young boy dreamed of becoming the greatest. |
| 6.0 – 8.5   | His name was Cristiano Ronaldo. |
| 9.0 – 14.5  | In 2003, he joined Manchester United, where the world began to witness his extraordinary talent. |
| 14.5 – 19.5 | In 2009, Real Madrid made him one of the most famous transfers in football history. |
| 20.0 – 25.5 | He conquered Europe, won five Ballon d'Or awards, and lifted five Champions League trophies. |
| 25.5 – 28.5 | From Manchester to Madrid, from Turin to the world. |
| 29.0 – 31.5 | His journey was never just about football. |
| 31.5 – 36.0 | It was about ambition, discipline, and an endless hunger for greatness. |
| 36.3 – 38.0 | Cristiano Ronaldo. |
| 38.0 – 40.5 | A name that became history. |
| 41.0 – 42.5 | This is VELTRO. |

## Audio status
- music.wav, ambience.wav, whoosh.wav, hit.wav: generated (original, copyright-free) by `npm run audio`.
- narration.mp3: PLACEHOLDER (no TTS engine available in the build environment).

## Free ways to produce the narration
1. Piper TTS (offline, free): `piper -m en_US-ryan-high.onnx -f narration.wav < script.txt`
2. edge-tts (free, no API key): `pip install edge-tts` then
   `edge-tts --voice en-US-GuyNeural --file script.txt --write-media public/audio/narration.mp3`
3. Record it yourself in Audacity (free) following the table above.
If the voice runs long/short, adjust the `from`/`to` values in CUES.
