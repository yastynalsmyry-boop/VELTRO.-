"""Generates original, copyright-free audio (pure Python, no dependencies):
music.wav (cinematic drone + pulse), ambience.wav (stadium murmur), whoosh.wav, hit.wav."""
import math, os, random, struct, wave

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'audio')
os.makedirs(OUT, exist_ok=True)
random.seed(7)


def write(name, samples):
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b''.join(struct.pack('<h', int(max(-1, min(1, s)) * 32767)) for s in samples))


def music(sec=45):
    n = SR * sec
    chords = [[110, 164.81, 220, 261.63, 329.63], [87.31, 130.81, 174.61, 220, 261.63],
              [65.41, 130.81, 196, 261.63, 329.63], [98, 146.83, 196, 246.94, 293.66]] * 2
    seg = sec / len(chords)
    out = [0.0] * n
    for ci, notes in enumerate(chords):
        s0 = ci * seg
        for i in range(int((seg + 2) * SR)):
            idx = int(s0 * SR) + i
            if idx >= n:
                break
            t = i / SR
            env = min(1, t / 1.5) * min(1, (seg + 2 - t) / 1.5)
            trem = 0.85 + 0.15 * math.sin(2 * math.pi * 0.25 * (idx / SR))
            v = sum(math.sin(2 * math.pi * f * t) + 0.3 * math.sin(4 * math.pi * f * t) for f in notes)
            out[idx] += v * env * trem * 0.035
    for b in range(8, sec * 2 - 6):  # soft low pulse that grows with the story
        t0 = b * 0.75
        gain = min(1, (t0 - 6) / 30) * 0.35
        for i in range(int(0.5 * SR)):
            idx = int(t0 * SR) + i
            if idx >= n:
                break
            tt = i / SR
            out[idx] += math.sin(2 * math.pi * 52 * tt) * math.exp(-tt * 9) * gain
    return out


def lowpass(x, a):
    y, p = [], 0.0
    for s in x:
        p += a * (s - p)
        y.append(p)
    return y


def ambience(sec=45):
    n = SR * sec
    noise = lowpass([random.uniform(-1, 1) for _ in range(n)], 0.07)
    swells = [(20, 3), (25, 2.5), (36, 3.5)]
    out = []
    for i, s in enumerate(noise):
        t = i / SR
        amp = 0.55 + 0.25 * math.sin(t * 0.7)
        for c, w in swells:
            amp += 0.5 * math.exp(-((t - c) ** 2) / (2 * w * w))
        out.append(s * amp * 1.6)
    return out


def whoosh(sec=0.6):
    n = int(SR * sec)
    out, p = [], 0.0
    for i in range(n):
        x = i / n
        a = 0.02 + 0.5 * x
        p += a * (random.uniform(-1, 1) - p)
        out.append(p * math.sin(math.pi * x) ** 2 * 2.2)
    return out


def hit(sec=1.6):
    n = int(SR * sec)
    return [(math.sin(2 * math.pi * 45 * (i / SR)) * 0.9 + random.uniform(-1, 1) * 0.3 * math.exp(-i / SR * 25)) * math.exp(-i / SR * 3.2) for i in range(n)]


for name, data in [('music', music()), ('ambience', ambience()), ('whoosh', whoosh()), ('hit', hit())]:
    write(name, data)
    print('wrote', name, round(len(data) / SR, 2), 's')
