# VELTRO — Cristiano Ronaldo: The Making of a Legend
Remotion + React · 1080×1920 (9:16) · 30 FPS · 1350 frames = 45 s

## Run
```bash
npm install
npm run audio     # generates music / ambience / sfx (Python 3, no deps)
npm run dev       # live preview in Remotion Studio
npm run render    # -> out/veltro.mp4
```
Direct command:
`npx remotion render src/index.ts Veltro out/veltro.mp4 --codec=h264 --crf=16`

Requires Node 18+. Fonts (Anton, Inter) are free Google Fonts loaded at render time (internet needed once).
Narration: see NARRATION.md.

## Structure
- src/config.ts   timeline, colors, subtitle cues, audio flags
- src/Scenes.tsx  all scenes (map, club scenes, honours, route timeline, kinetic legacy, logo)
- src/ui.tsx      background, particles, subtitles, counters, wipes
- src/Video.tsx   composition + audio layer
