import React from 'react';
import {Composition} from 'remotion';
import {DURATION, FPS, HEIGHT, WIDTH} from './config';
import {Veltro} from './Video';

export const Root: React.FC = () => (
  <Composition
    id="Veltro"
    component={Veltro}
    durationInFrames={DURATION}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
