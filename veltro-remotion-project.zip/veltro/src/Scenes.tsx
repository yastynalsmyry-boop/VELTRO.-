import React from 'react';
import {AbsoluteFill, Easing, Sequence, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {COLORS} from './config';
import {BODY, DISPLAY} from './fonts';
import {Counter, Kinetic, LowerThird, Rays, clamp, goldGradient} from './ui';

const MAP_W = 1080;
const MAP_H = 900;
const MADEIRA = {x: 345, y: 650};
const LISBON = {x: 570, y: 300};

// ---------------- 1. ORIGINS: animated map of Madeira ----------------
export const OriginsScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const draw = interpolate(frame, [8, 70], [1, 0], clamp);
  const route = interpolate(frame, [50, 130], [1, 0], clamp);
  const fill = interpolate(frame, [50, 90], [0, 0.12], clamp);
  const z = interpolate(frame, [60, 170], [0, 1], {...clamp, easing: Easing.inOut(Easing.cubic)});
  const scale = 1 + 0.9 * z;
  const mapOpacity = interpolate(frame, [170, 190], [1, 0.18], clamp);
  const pin = spring({frame: frame - 120, fps, config: {damping: 10}});
  const pulse = (frame % 45) / 45;
  const head = interpolate(frame, [10, 30], [0, 1], clamp);

  const iberia = 'M640 40 L900 30 L1040 60 L1070 150 L1000 260 L900 340 L820 430 L740 470 L640 450 L590 380 L575 300 L560 220 L585 140 L600 90 Z';
  const madeira = 'M280 640 L320 615 L370 620 L395 645 L360 665 L300 662 Z';
  const africa = 'M760 820 L1080 770 L1080 900 L700 900 Z';
  const outline = (d: string, off: number, f: number) => (
    <path d={d} pathLength={1} strokeDasharray={1} strokeDashoffset={off} fill={COLORS.gold} fillOpacity={f} stroke={COLORS.goldLight} strokeWidth={3} />
  );

  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', top: 190, width: '100%', textAlign: 'center', opacity: head}}>
        <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 30, letterSpacing: 14, color: COLORS.goldLight}}>VELTRO PRESENTS</div>
        <div style={{fontFamily: DISPLAY, fontSize: 84, letterSpacing: 6, color: COLORS.white, marginTop: 14}}>THE MAKING OF A LEGEND</div>
      </div>

      <div style={{position: 'absolute', top: 400, left: 0, width: MAP_W, height: MAP_H, overflow: 'hidden', opacity: mapOpacity, borderTop: `2px solid ${COLORS.goldDark}`, borderBottom: `2px solid ${COLORS.goldDark}`}}>
        <svg
          width={MAP_W} height={MAP_H} viewBox={`0 0 ${MAP_W} ${MAP_H}`}
          style={{transformOrigin: `${MADEIRA.x}px ${MADEIRA.y}px`, transform: `translate(${195 * z}px, ${-90 * z}px) scale(${scale})`}}
        >
          {Array.from({length: 9}).map((_, i) => (
            <line key={`h${i}`} x1={0} x2={MAP_W} y1={i * 100 + 50} y2={i * 100 + 50} stroke={COLORS.goldDark} strokeOpacity={0.25} strokeWidth={1} />
          ))}
          {Array.from({length: 11}).map((_, i) => (
            <line key={`v${i}`} y1={0} y2={MAP_H} x1={i * 100 + 40} x2={i * 100 + 40} stroke={COLORS.goldDark} strokeOpacity={0.25} strokeWidth={1} />
          ))}
          {outline(africa, draw, fill * 0.6)}
          {outline(iberia, draw, fill)}
          {outline(madeira, draw, fill * 3)}
          <text x={600} y={250} fontFamily={DISPLAY} fontSize={34} letterSpacing={6} fill={COLORS.white} opacity={0.8}>PORTUGAL</text>
          <text x={80} y={420} fontFamily={BODY} fontWeight={700} fontSize={26} letterSpacing={10} fill={COLORS.goldLight} opacity={0.6}>ATLANTIC OCEAN</text>
          <circle cx={LISBON.x} cy={LISBON.y} r={9} fill={COLORS.white} />
          <text x={LISBON.x + 20} y={LISBON.y + 10} fontFamily={BODY} fontWeight={700} fontSize={24} fill={COLORS.white}>LISBON</text>
          <path d={`M${LISBON.x} ${LISBON.y} Q 380 400 ${MADEIRA.x} ${MADEIRA.y - 10}`} pathLength={1} strokeDasharray="0.02 0.02" strokeDashoffset={route * 0.5} fill="none" stroke={COLORS.goldLight} strokeWidth={4} opacity={1 - route} />
          <circle cx={MADEIRA.x} cy={MADEIRA.y} r={10 + 50 * pulse * pin} fill="none" stroke={COLORS.goldLight} strokeWidth={3} opacity={(1 - pulse) * pin} />
          <circle cx={MADEIRA.x} cy={MADEIRA.y} r={12 * pin} fill={COLORS.goldLight} />
          <text x={MADEIRA.x - 70} y={MADEIRA.y + 70} fontFamily={DISPLAY} fontSize={34} letterSpacing={4} fill={COLORS.goldLight} opacity={pin}>MADEIRA</text>
          <text x={MADEIRA.x - 70} y={MADEIRA.y + 100} fontFamily={BODY} fontWeight={500} fontSize={20} letterSpacing={3} fill={COLORS.white} opacity={pin}>32.65°N · 16.91°W</text>
        </svg>
      </div>

      <Sequence from={180}>
        <div style={{position: 'absolute', top: 560, width: '100%'}}>
          <Kinetic words={['CRISTIANO', 'RONALDO']} size={190} gold stagger={10} />
        </div>
      </Sequence>
      <Sequence from={240}>
        <LowerThird text="2002 · SPORTING CP · LISBON" top={1180} />
      </Sequence>
    </AbsoluteFill>
  );
};

// ---------------- 2/3. CLUB SCENES ----------------
type Stat = {value: number; label: string};

export const ClubScene: React.FC<{
  year: number; club: string[]; tagline: string; chapter: string; stats: Stat[];
}> = ({year, club, tagline, chapter, stats}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const shownYear = Math.round(interpolate(frame, [0, 36], [year - 30, year], {...clamp, easing: Easing.out(Easing.cubic)}));
  const tag = interpolate(frame, [30, 52], [0, 1], clamp);
  const ghostY = interpolate(frame, [0, 165], [60, -60]);

  return (
    <AbsoluteFill>
      <Rays />
      <div style={{position: 'absolute', top: 150 + ghostY, width: '100%', textAlign: 'center', fontFamily: DISPLAY, fontSize: 1600, lineHeight: 1, color: 'transparent', WebkitTextStroke: '4px rgba(212,175,55,0.16)'}}>7</div>
      <div style={{position: 'absolute', top: 210, width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20}}>
        <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 32, letterSpacing: 12, color: COLORS.goldLight, opacity: tag}}>{chapter}</div>
        <div style={{fontFamily: DISPLAY, fontSize: 340, lineHeight: 1, letterSpacing: 8, ...goldGradient(frame)}}>{shownYear}</div>
        <Kinetic words={club} size={130} start={22} stagger={8} />
        <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 36, letterSpacing: 10, color: COLORS.white, opacity: tag, marginTop: 10}}>{tagline}</div>
      </div>
      <div style={{position: 'absolute', top: 1090, left: 60, right: 60, display: 'flex', gap: 20, justifyContent: 'center'}}>
        {stats.map((s, i) => {
          const p = spring({frame: frame - (50 + i * 10), fps, config: {damping: 14}});
          return (
            <div key={i} style={{flex: 1, border: `2px solid ${COLORS.goldDark}`, background: 'rgba(255,255,255,0.05)', padding: '26px 10px', textAlign: 'center', transform: `translateY(${(1 - p) * 60}px)`, opacity: p}}>
              <Counter to={s.value} size={104} start={55 + i * 10} dur={40} />
              <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 25, letterSpacing: 4, color: COLORS.white, marginTop: 14}}>{s.label}</div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

export const UnitedScene: React.FC = () => (
  <ClubScene year={2003} club={['MANCHESTER', 'UNITED']} chapter="THE BREAKTHROUGH" tagline="OLD TRAFFORD · 2003–2009"
    stats={[{value: 3, label: 'LEAGUE TITLES'}, {value: 118, label: 'GOALS'}, {value: 1, label: 'CHAMPIONS LEAGUE'}]} />
);

export const MadridScene: React.FC = () => (
  <ClubScene year={2009} club={['REAL', 'MADRID']} chapter="THE HISTORIC TRANSFER" tagline="SANTIAGO BERNABÉU · 2009–2018"
    stats={[{value: 450, label: 'GOALS'}, {value: 438, label: 'MATCHES'}, {value: 4, label: 'CHAMPIONS LEAGUES'}]} />
);

// ---------------- 4. HONOURS ----------------
const star = (cx: number, cy: number, R: number, r: number) =>
  Array.from({length: 10}, (_, i) => {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 === 0 ? R : r;
    return `${cx + rad * Math.cos(a)},${cy + rad * Math.sin(a)}`;
  }).join(' ');

const BallIcon: React.FC<{size: number}> = ({size}) => {
  const pent = [[50, 30], [69, 44], [62, 66], [38, 66], [31, 44]];
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <defs>
        <radialGradient id="ballG" cx="35%" cy="30%">
          <stop offset="0" stopColor={COLORS.goldLight} />
          <stop offset="1" stopColor={COLORS.goldDark} />
        </radialGradient>
      </defs>
      <circle cx={50} cy={50} r={46} fill="url(#ballG)" />
      <g stroke="#0b0b0c" strokeWidth={2} opacity={0.6}>
        {pent.map(([x, y], i) => (
          <line key={i} x1={x} y1={y} x2={50 + (x - 50) * 1.55} y2={50 + (y - 50) * 1.55} />
        ))}
      </g>
      <polygon points={pent.map((p) => p.join(',')).join(' ')} fill="#0b0b0c" opacity={0.85} />
    </svg>
  );
};

const StarIcon: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <defs>
      <linearGradient id="starG" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={COLORS.goldLight} />
        <stop offset="1" stopColor={COLORS.goldDark} />
      </linearGradient>
    </defs>
    <circle cx={50} cy={50} r={46} fill="none" stroke="url(#starG)" strokeWidth={5} />
    <polygon points={star(50, 52, 30, 12)} fill="url(#starG)" />
  </svg>
);

const Honour: React.FC<{icon: 'ball' | 'star'; label: string; years: string[]; start: number}> = ({icon, label, years, start}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - start, fps, config: {damping: 14}});
  return (
    <div style={{border: `2px solid ${COLORS.goldDark}`, background: 'rgba(0,0,0,0.45)', padding: '30px 30px 34px', opacity: p, transform: `translateY(${(1 - p) * 70}px)`}}>
      <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 50}}>
        {icon === 'ball' ? <BallIcon size={230} /> : <StarIcon size={230} />}
        <Counter to={5} size={300} start={start + 8} dur={36} />
      </div>
      <div style={{fontFamily: DISPLAY, fontSize: 70, letterSpacing: 6, color: COLORS.white, textAlign: 'center', marginTop: 18}}>{label}</div>
      <div style={{display: 'flex', gap: 10, justifyContent: 'center', marginTop: 20}}>
        {years.map((y, i) => {
          const c = interpolate(frame, [start + 40 + i * 5, start + 52 + i * 5], [0, 1], clamp);
          return (
            <span key={y} style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, color: COLORS.goldLight, border: `1px solid ${COLORS.goldDark}`, padding: '6px 14px', opacity: c}}>{y}</span>
          );
        })}
      </div>
    </div>
  );
};

export const HonoursScene: React.FC = () => (
  <AbsoluteFill style={{padding: '200px 60px 0', gap: 34, display: 'flex', flexDirection: 'column'}}>
    <Honour icon="ball" label="BALLON D'OR AWARDS" years={['2008', '2013', '2014', '2016', '2017']} start={0} />
    <Honour icon="star" label="CHAMPIONS LEAGUE TITLES" years={['2008', '2014', '2016', '2017', '2018']} start={40} />
  </AbsoluteFill>
);

// ---------------- 5. ROUTE / CAREER TIMELINE ----------------
const STOPS = [
  {year: '2002', city: 'LISBON', club: 'SPORTING CP'},
  {year: '2003', city: 'MANCHESTER', club: 'MANCHESTER UNITED'},
  {year: '2009', city: 'MADRID', club: 'REAL MADRID'},
  {year: '2018', city: 'TURIN', club: 'JUVENTUS'},
  {year: 'TODAY', city: 'THE WORLD', club: 'A GLOBAL ICON'},
];

export const RouteScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const line = interpolate(frame, [4, 75], [0, 800], {...clamp, easing: Easing.out(Easing.cubic)});
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 170, top: 330}}>
        <div style={{position: 'absolute', left: -3, top: 40, width: 6, height: line, background: `linear-gradient(${COLORS.goldLight}, ${COLORS.gold})`}} />
        {STOPS.map((s, i) => {
          const p = spring({frame: frame - (6 + i * 14), fps, config: {damping: 13}});
          return (
            <div key={s.city} style={{position: 'absolute', top: i * 200, left: 0, opacity: p, transform: `translateX(${(1 - p) * 80}px)`}}>
              <div style={{position: 'absolute', left: -19, top: 34, width: 38, height: 38, borderRadius: '50%', background: COLORS.goldLight, boxShadow: `0 0 30px ${COLORS.gold}`}} />
              <div style={{marginLeft: 70}}>
                <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 34, letterSpacing: 8, color: COLORS.goldLight}}>{s.year}</div>
                <div style={{fontFamily: DISPLAY, fontSize: 96, lineHeight: 1.05, letterSpacing: 4, color: COLORS.white}}>{s.city}</div>
                <div style={{fontFamily: BODY, fontWeight: 500, fontSize: 28, letterSpacing: 8, color: COLORS.white, opacity: 0.7}}>{s.club}</div>
              </div>
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

// ---------------- 6. LEGACY: kinetic typography ----------------
const Beat: React.FC<{from: number; dur: number; words: string[]; size: number; gold?: boolean; rays?: boolean}> = ({from, dur, words, size, gold, rays}) => (
  <Sequence from={from} durationInFrames={dur}>
    <BeatInner dur={dur} words={words} size={size} gold={gold} rays={rays} />
  </Sequence>
);

const BeatInner: React.FC<{dur: number; words: string[]; size: number; gold?: boolean; rays?: boolean}> = ({dur, words, size, gold, rays}) => {
  const frame = useCurrentFrame();
  const out = interpolate(frame, [dur - 6, dur], [1, 0], clamp);
  const line = interpolate(frame, [8, 30], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  return (
    <AbsoluteFill style={{opacity: out, justifyContent: 'center', alignItems: 'center', paddingBottom: 260}}>
      {rays ? <Rays /> : null}
      <Kinetic words={words} size={size} gold={gold} stagger={4} />
      <div style={{height: 6, width: `${line * 560}px`, background: `linear-gradient(90deg, ${COLORS.gold}, ${COLORS.goldLight})`, marginTop: 40}} />
    </AbsoluteFill>
  );
};

export const LegacyScene: React.FC = () => (
  <AbsoluteFill>
    <Beat from={0} dur={78} words={['HIS', 'JOURNEY', 'WAS', 'NEVER', 'JUST', 'ABOUT', 'FOOTBALL']} size={120} />
    <Beat from={75} dur={48} words={['AMBITION']} size={200} gold />
    <Beat from={120} dur={48} words={['DISCIPLINE']} size={200} gold />
    <Beat from={165} dur={48} words={['ENDLESS', 'HUNGER']} size={190} gold />
    <Beat from={210} dur={58} words={['CRISTIANO', 'RONALDO']} size={190} gold rays />
    <Beat from={265} dur={80} words={['A', 'NAME', 'THAT', 'BECAME', 'HISTORY.']} size={130} gold />
  </AbsoluteFill>
);

// ---------------- 7. VELTRO LOGO ----------------
export const LogoScene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const mark = spring({frame: frame - 4, fps, config: {damping: 12, stiffness: 90}});
  const line = interpolate(frame, [40, 75], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const tag = interpolate(frame, [55, 80], [0, 1], clamp);
  const sweep = interpolate(frame, [30, 85], [-300, 1100], clamp);
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', paddingBottom: 300}}>
      <Rays />
      <svg width={240} height={226} viewBox="0 0 180 170" style={{transform: `scale(${mark}) rotate(${(1 - mark) * -25}deg)`, filter: `drop-shadow(0 0 30px ${COLORS.gold})`}}>
        <defs>
          <linearGradient id="vG" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor={COLORS.goldLight} />
            <stop offset="1" stopColor={COLORS.goldDark} />
          </linearGradient>
        </defs>
        <polygon points="0,0 42,0 90,112 138,0 180,0 110,165 70,165" fill="url(#vG)" />
      </svg>
      <div style={{position: 'relative', overflow: 'hidden', marginTop: 30, display: 'flex'}}>
        {'VELTRO'.split('').map((l, i) => {
          const p = spring({frame: frame - (18 + i * 5), fps, config: {damping: 14}});
          return (
            <span key={i} style={{fontFamily: DISPLAY, fontSize: 200, lineHeight: 1.1, letterSpacing: 24, opacity: p, transform: `translateY(${(1 - p) * 80}px)`, ...goldGradient(frame)}}>{l}</span>
          );
        })}
        <div style={{position: 'absolute', top: 0, bottom: 0, left: sweep, width: 120, background: 'rgba(255,255,255,0.55)', transform: 'skewX(-20deg)', filter: 'blur(14px)'}} />
      </div>
      <div style={{height: 4, width: `${line * 720}px`, background: `linear-gradient(90deg, transparent, ${COLORS.goldLight}, transparent)`, margin: '24px 0'}} />
      <div style={{fontFamily: BODY, fontWeight: 700, fontSize: 44, letterSpacing: 14, color: COLORS.white, opacity: tag, transform: `translateY(${(1 - tag) * 16}px)`}}>
        THIS IS FOOTBALL HISTORY.
      </div>
    </AbsoluteFill>
  );
};
