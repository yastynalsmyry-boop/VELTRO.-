import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile} from 'remotion';
import {COLORS, DURATION, FEATURES, SCENES} from './config';
import {HonoursScene, LegacyScene, LogoScene, MadridScene, OriginsScene, RouteScene, UnitedScene} from './Scenes';
import {Background, Chrome, GoldWipe, SceneShell, Subtitles, clamp} from './ui';

const S = SCENES;
const BOUNDARIES = [S.united.from, S.madrid.from, S.honours.from, S.route.from, S.legacy.from, S.logo.from];

const scene = (key: keyof typeof SCENES, node: React.ReactNode) => (
  <Sequence from={S[key].from} durationInFrames={S[key].dur}>
    <SceneShell dur={S[key].dur} zoom={key === 'logo' ? 0.03 : 0.08}>{node}</SceneShell>
  </Sequence>
);

const AudioLayer: React.FC = () => (
  <>
    {FEATURES.music && (
      <Audio src={staticFile('audio/music.wav')} volume={(f) => interpolate(f, [0, 30, DURATION - 60, DURATION], [0, 0.45, 0.45, 0], clamp)} />
    )}
    {FEATURES.ambience && <Audio src={staticFile('audio/ambience.wav')} volume={0.25} />}
    {FEATURES.sfx && BOUNDARIES.map((b) => (
      <Sequence key={b} from={b - 8}>
        <Audio src={staticFile('audio/whoosh.wav')} volume={0.6} />
      </Sequence>
    ))}
    {FEATURES.sfx && (
      <Sequence from={S.logo.from}>
        <Audio src={staticFile('audio/hit.wav')} volume={0.9} />
      </Sequence>
    )}
    {FEATURES.narration && <Audio src={staticFile('audio/narration.mp3')} volume={1} />}
  </>
);

export const Veltro: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: COLORS.black}}>
    <Background />
    {scene('origins', <OriginsScene />)}
    {scene('united', <UnitedScene />)}
    {scene('madrid', <MadridScene />)}
    {scene('honours', <HonoursScene />)}
    {scene('route', <RouteScene />)}
    {scene('legacy', <LegacyScene />)}
    {scene('logo', <LogoScene />)}
    <Chrome total={DURATION} />
    <Subtitles />
    {BOUNDARIES.map((b) => (
      <Sequence key={b} from={b - 8} durationInFrames={16}>
        <GoldWipe />
      </Sequence>
    ))}
    <AudioLayer />
  </AbsoluteFill>
);
