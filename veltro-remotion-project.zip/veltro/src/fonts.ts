import {loadFont as loadAnton} from '@remotion/google-fonts/Anton';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

export const DISPLAY = loadAnton().fontFamily;
export const BODY = loadInter('normal', {weights: ['500', '700']}).fontFamily;
