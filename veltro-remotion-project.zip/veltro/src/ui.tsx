import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {COLORS, CUES, FPS, HEIGHT, WIDTH} from './config';
import {BODY, DISPLAY} from './fonts';

export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const goldGradient = (frame: number): React.CSSProperties => ({
  backgroundImage: `linear-gradient(110deg, ${COLORS.goldDark} 0%, ${COLORS.gold} 30%, ${COLORS.goldLight} 50%, ${COLORS.gold} 70%, ${COLORS.goldDark} 100%)`,
  backgroundSize: '250% 100%',
  backgroundPosition: `${50 + 50 * Math.sin(frame / 40)}% 50%`,
  WebkitBackgroundClip: 'text',
  backgroundClip: 'text',
  color: 'transparent',
  WebkitTextFillColor: 'transparent',
});

const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      {Array.from({length: 48}).map((_, i) => {
        const speed = 0.8 + (i % 7) * 0.35;
        const y = HEIGHT - ((frame * speed * 2 + i * 211) % (HEIGHT + 100));
        const x = ((i * 173) % WIDTH) + Math.sin(frame / 40 + i) * 20;
        const r = 2 + (i % 4);
        const o = 0.35 + 0.35 * Math.sin(frame / 12 + i);
        return (
          <div
            key={i}
            style={{
              position: 'absolute', left: x, top: y, width: r * 2, height: r * 2,
              borderRadius: '50%', background: COLORS.goldLight, opacity: o,
              boxShadow: `0 0 ${r * 4}px ${COLORS.gold}`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

export const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const gx = 50 + 18 * Math.sin(frame / 90);
  return (
    <AbsoluteFill
      style={{background: `radial-gradient(ellipse 80% 55% at ${gx}% 38%, #2a2210 0%, #0b0b0c 55%, #030303 100%)`}}
    >
      <Particles />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, transparent 55%, rgba(0,0,0,0.75) 100%)'}} />
    </AbsoluteFill>
  );
};

export const SceneShell: React.FC<{dur: number; zoom?: number; children: React.ReactNode}> = ({dur, zoom = 0.08, children}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 8, dur - 8, dur], [0, 1, 1, 0], clamp);
  const scale = interpolate(frame, [0, dur], [1, 1 + zoom]);
  return <AbsoluteFill style={{opacity, transform: `scale(${scale})`}}>{children}</AbsoluteFill>;
};

export const Kinetic: React.FC<{
  words: string[]; size: number; start?: number; stagger?: number; gold?: boolean; color?: string;
}> = ({words, size, start = 0, stagger = 6, gold = false, color = COLORS.white}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: `0 ${size * 0.28}px`, width: '100%', padding: '0 80px', boxSizing: 'border-box', textAlign: 'center'}}>
      {words.map((w, i) => {
        const p = spring({frame: frame - start - i * stagger, fps, config: {damping: 14, stiffness: 120}});
        return (
          <span
            key={i}
            style={{
              display: 'inline-block', fontFamily: DISPLAY, fontSize: size, lineHeight: 1.08,
              letterSpacing: size * 0.02, transform: `translateY(${(1 - p) * 90}px) scale(${0.9 + 0.1 * p})`,
              opacity: Math.min(1, p * 1.6), ...(gold ? goldGradient(frame) : {color}),
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

export const Counter: React.FC<{to: number; size: number; start?: number; dur?: number}> = ({to, size, start = 0, dur = 40}) => {
  const frame = useCurrentFrame();
  const v = Math.round(interpolate(frame, [start, start + dur], [0, to], {...clamp, easing: Easing.out(Easing.cubic)}));
  return <span style={{fontFamily: DISPLAY, fontSize: size, lineHeight: 1, ...goldGradient(frame)}}>{v}</span>;
};

export const Rays: React.FC = () => {
  const frame = useCurrentFrame();
  const mask = 'radial-gradient(circle at 50% 42%, black 0%, transparent 65%)';
  return (
    <AbsoluteFill
      style={{
        background: `repeating-conic-gradient(from ${frame * 0.6}deg at 50% 42%, rgba(246,226,122,0.16) 0deg 6deg, transparent 6deg 18deg)`,
        WebkitMaskImage: mask, maskImage: mask,
      }}
    />
  );
};

export const LowerThird: React.FC<{text: string; top: number}> = ({text, top}) => {
  const frame = useCurrentFrame();
  const bar = interpolate(frame, [0, 18], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});
  const txt = interpolate(frame, [10, 26], [0, 1], clamp);
  return (
    <div style={{position: 'absolute', left: 80, top, width: 920}}>
      <div style={{height: 6, width: `${bar * 100}%`, background: `linear-gradient(90deg, ${COLORS.gold}, ${COLORS.goldLight})`}} />
      <div style={{fontFamily: DISPLAY, fontSize: 58, letterSpacing: 6, color: COLORS.white, marginTop: 18, opacity: txt, transform: `translateY(${(1 - txt) * 20}px)`}}>
        {text}
      </div>
    </div>
  );
};

export const Subtitles: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const cue = CUES.find((c) => t >= c.from && t < c.to);
  if (!cue) return null;
  const a = interpolate(t, [cue.from, cue.from + 0.2, cue.to - 0.2, cue.to], [0, 1, 1, 0], clamp);
  return (
    <div style={{position: 'absolute', left: 70, right: 70, bottom: 380, textAlign: 'center', opacity: a, transform: `translateY(${(1 - a) * 14}px)`}}>
      <span
        style={{
          fontFamily: BODY, fontWeight: 700, fontSize: 50, lineHeight: 1.35, color: COLORS.white,
          background: 'rgba(0,0,0,0.6)', padding: '6px 18px',
          boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone',
        }}
      >
        {cue.text}
      </span>
    </div>
  );
};

export const GoldWipe: React.FC = () => {
  const frame = useCurrentFrame();
  const x = interpolate(frame, [0, 16], [-WIDTH * 1.4, WIDTH * 1.4], clamp);
  return (
    <AbsoluteFill style={{overflow: 'hidden', pointerEvents: 'none'}}>
      <div
        style={{
          position: 'absolute', top: -200, left: 0, width: 360, height: HEIGHT + 400,
          transform: `translateX(${x}px) rotate(18deg)`,
          background: `linear-gradient(90deg, transparent, ${COLORS.goldLight}, transparent)`,
          opacity: 0.85, filter: 'blur(6px)',
        }}
      />
    </AbsoluteFill>
  );
};

export const Chrome: React.FC<{total: number}> = ({total}) => {
  const frame = useCurrentFrame();
  return (
    <>
      <div style={{position: 'absolute', left: 0, top: 70, height: 4, width: `${(frame / total) * 100}%`, background: COLORS.gold}} />
      <div style={{position: 'absolute', left: 60, top: 100, fontFamily: DISPLAY, fontSize: 40, letterSpacing: 12, color: COLORS.gold, opacity: 0.9}}>
        VELTRO
      </div>
    </>
  );
};
